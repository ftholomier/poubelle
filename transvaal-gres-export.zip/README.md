# Export du site transvaal-gres.fr (25/10/2026)

Site WordPress (thème The7 + WPBakery) — Transvaal Grès, salles de bains, cuisines, carrelages (Montbéliard / Belfort).

- `www.transvaal-gres.fr/` : miroir HTML statique (images recompressées, max 1000px) (pages, CSS, JS, images, polices), consultable hors ligne via `index.html`.
- `_screenshots/` : captures pleine page (JPEG 900px) des pages principales.

## Arborescence
Accueil · Qui sommes-nous · Salles de bains (clé en main, meubles, robinetterie & accessoires) · Cuisines · Carrelages (carrelages, extérieurs, faïences) · Aménagement · Énergies · Showroom · Galerie · Expérience 3D · Contact · Mentions légales

## Identité visuelle relevée
- Bleu marine principal : #0b2447 — Bleu acier accent : #5b8eab
- Texte : #333333 — gris : #b1b4b8 / #8b8d94 — fond : #ffffff
- Typos : Work Sans (titres), Roboto (texte)
- Images : `www.transvaal-gres.fr/wp-content/uploads/`
